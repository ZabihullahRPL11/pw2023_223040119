<footer class="footer">

   <section class="grid">

      <div class="box">
         <img src="images/email-icon.png" alt="">
         <h3>email kami</h3>
         <a href="mailto:zaachaf@gmail.com">zaachaf@gmail.com</a>
      </div>

      <div class="box">
         <img src="images/clock-icon.png" alt="">
         <h3>buka</h3>
         <p>08:00am to 22:00pm</p>
      </div>

      <div class="box">
         <img src="images/map-icon.png" alt="">
         <h3>alamat kami</h3>
         <a href="#">arcamanik, kota bandung</a>
      </div>

      <div class="box">
         <img src="images/phone-icon.png" alt="">
         <h3>nomor kami</h3>
         <a href="tel:087838182550">0878-3818-2550</a>
      </div>

   </section>

   <div class="credit">&copy; copyright @ <?= date('Y'); ?> by <span>zaachaf</span> | all rights reserved!</div>

</footer>

<div class="loader">
   <img src="images/loader.gif" alt="">
</div>